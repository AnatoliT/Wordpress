=== Plugin Name ===
Contributors: custom
Donate link: http://www.3cc.org/
Tags: custom_dashboard
Requires at least: 3
Tested up to: 4.3.1
Stable tag: 1.3.1

custom_dashboard.
