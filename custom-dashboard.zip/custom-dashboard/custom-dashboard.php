<?php



/*



Plugin Name: custom dashboard



Version: 1.3.1



Plugin URI: http://www.3cc.org/scripts/wp-seatt-simple-event-attendance/



Author: custom custom



Author URI: http://www.3cc.org



Description: custom dashboard.



*/



// plugin folder url

if(!defined('RC_SCD_PLUGIN_URL')) {

	define('RC_SCD_PLUGIN_URL', plugin_dir_url( __FILE__ ));

}





/*

|--------------------------------------------------------------------------

| MAIN CLASS

|--------------------------------------------------------------------------

*/



class rc_sweet_custom_dashboard {



	/*--------------------------------------------*

	 * Constructor

	 *--------------------------------------------*/



	/**

	 * Initializes the plugin

	 */

	function __construct() {

		add_action('admin_menu', array( &$this,'rc_scd_register_menu') );

		add_action('load-index.php', array( &$this,'rc_scd_redirect_dashboard') );

	} // end constructor


function rc_scd_redirect_dashboard() {



	if( is_admin() ) {

		$screen = get_current_screen();

		

		if( $screen->base == 'dashboard' ) {



			wp_redirect( admin_url( 'index.php?page=custom-dashboard' ) );

			

		}

	}



}




function rc_scd_register_menu() {

	add_dashboard_page( 'Custom Dashboard', 'Custom Dashboard', 'read', 'custom-dashboard', array( &$this,'rc_scd_create_dashboard') );

}



function rc_scd_create_dashboard() {

	include_once( 'custom_dashboard.php'  );

}



}



// instantiate plugin's class

$GLOBALS['sweet_custom_dashboard'] = new rc_sweet_custom_dashboard();



?>