<?php

/**

 * Our custom dashboard page

 */



/** WordPress Administration Bootstrap */

require_once( ABSPATH . 'wp-load.php' );

require_once( ABSPATH . 'wp-admin/admin.php' );

require_once( ABSPATH . 'wp-admin/admin-header.php' );

?>

<link rel="stylesheet" href="<?php ABSPATH ; ?>/wp-content/themes/careadvisor/libraries/bootstrap/css/bootstrap.min.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php ABSPATH ; ?>/wp-content/plugins/custom-dashboard/style.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php ABSPATH ; ?>/wp-content/plugins/custom-dashboard/nivo-slider.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php ABSPATH ; ?>/wp-content/plugins/custom-dashboard/default.css" type="text/css" media="screen" />

<script type="text/javascript" src="<?php ABSPATH ; ?>/wp-content/plugins/custom-dashboard/jquery.nivo.slider.js"></script>
	
	
<div class="wrap about-wrap">

<h2><?php _e( 'CARE ADVISOR' ); ?></h2>



<style>#wpbody, body{background-color: #ececec;}</style>



<?php
$user = cadl_user(get_current_user_id());
?>
  <div class="row user-profile jobseeker">
  <div class="col-sm-6 summary">
    <div class="wrap gold-border">
      <div class="row">
        <!--<div class="col-sm-6">-->
          <div class="photo">
            <div class="frame">
              <?php echo(get_avatar($user->id, 240)); ?>
            </div>
          </div>
        <!--</div>-->
		
		<!--
        <div class="col-sm-6">
          
        </div>
		-->
      </div>
	  <div class="photo" style="padding:10px">
            AUTHOR RATING
      </div>
	  
      <div class="stars yellow">
        <?php echo($user->getStars(true)); ?>
      </div>
	  
	  <div class="photo" style="padding:10px">
           <?php //if ($user->id != get_current_user_id()) { ?>
          <div class="action">
			<!--
            <?php //if ($user->isFavorited(get_current_user_id())) { ?>
            <a class="btn btn-default favorite" href="#" title="Is your favorite!">
              <i class="fa fa-heart favorite-done"> Favorited!</i>
            </a>
            <?php //} else { ?> -->
            <a class="btn btn-default favorite" id="userDoFavorite" href="#" title="Add favorite!" data-user="<?php echo($user->id); ?>">
              <span class="favorite-do"><i class="fa fa-heart-o"></i> Favorite</span>
              <span class="favorite-progress" style="display:none;"><i class="fa fa-circle-o-notch fa-spin"></i> Favoriting</span>
              <span class="favorite-done" style="display:none;"><i class="fa fa-heart"></i> Favorited!</span>
            </a>
            <?php //} ?>
            <a class="btn btn-info message" href="<?php echo($messageUrl . '?user=' . $user->id); ?>" title="Send message to this user"><i class="fa fa-envelope-o"></i> Message</a>
			
			<a class="btn btn-info message" href="<?php echo($messageUrl . '?user=' . $user->id); ?>" title="Send message to this user"><i class="fa fa-envelope-o"></i> EDIT PROFILE</a>
		  </div>
          <?php //} ?>
      </div>
	  
	  
      <p class="description"><?php echo(get_the_author_meta('description', $user->id)); ?></p>
      <div class="review">
        <p>PREVIOUS REVIEWS</p>
	
	<!--
        <a class="btn btn-default" href="<?php echo($reviewUrl); ?>?user=<?php echo($user->id); ?>">Review</a>
	-->

        <?php if ($hasReview) { ?>
        <a class="btn btn-info" href="/profile/reviews?user=<?php echo($user->id); ?>">Read More Reviews</a>
        <?php } ?>
      </div>
    </div>
  </div>
  <div class="col-sm-6" style="">
    <div class="row">
      <div class="col-sm-12 detail">
        <div class="wrap" style="margin: 10px 0px 0 2px;">
          <div class="row">
            <div class="col-sm-12 field first">
              <?php echo($user->userName); ?>
            </div>
            <div class="col-sm-5 field">
              Address:
            </div>
            <div class="col-sm-7 value">
              <?php echo(strlen(''.$user->detail->townName) > 0 ? $user->detail->townName . ', Co ' . $user->detail->countyName : '-'); ?>
            </div>
            <div class="col-sm-5 field">
              Care Home Type: <!--Garda Clearance:-->
            </div>
            <div class="col-sm-7 value">
              <?php echo(strlen(''.$user->detail->gardaName) > 0 ? $user->detail->gardaName : '-'); ?>
            </div>
			<!--
            <div class="col-sm-5 field">
              Qualifications:
            </div>
			
            <div class="col-sm-7 value">
              <?php echo($user->getQualifications()); ?>
            </div>
			-->
			<!--
            <div class="col-sm-5 field">
              CV:
            </div>
            <div class="col-sm-7 value">
              <a href="<?php echo($user->detail->cv); ?>" target="_blank">View</a>
            </div>
			-->
            <div class="col-sm-5 field">
              Years in Business:
            </div>
            <div class="col-sm-7 value">
              23 Years <?php echo($user->detail->yearExperience); ?>
            </div>
            <div class="col-sm-12 field last">
              <?php echo($hasReview ? '&quot;' . $theReview->content . '&quot;' : 'No review yet!'); ?>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-12 info">
        <div class="list">
          <div class="row">
            <div class="col-sm-4 field">
              Specialising in:
            </div>
            <div class="col-sm-8 value">
              <?php echo(strtolower($user->getSpecializations())); ?>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-4 field">
              Special interests:
            </div>
            <div class="col-sm-8 value">
              <?php echo($user->detail->interests); ?>
            </div>
          </div>

	<!--
          <div class="row">
            <div class="col-sm-4 field">
              Previous employers:
            </div>
            <div class="col-sm-8 value">
              <?php echo(isset($data['pre']) ? $data['pre'] : '-'); ?>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-4 field">
              Current employers:
            </div>
            <div class="col-sm-8 value">
              <?php echo(isset($data['cur']) ? $data['cur'] : '-'); ?>
            </div>
          </div>
	-->

        </div>
      </div>
	  
	  <div class="col-sm-12 info" style="margin-top: 15px;">
			
			 <div class="slider-wrapper theme-default">
				<div id="slider" class="nivoSlider">
				
				<?php
					$user->images->load();
					foreach ($user->images as $image) { ?>
						<!--  Images to slide through.  -->
						<img src="<?php echo $image->url; ?>" />
					<?php } ?>	
				</div>
				
			</div>
			
	  </div>
	  
    </div>
  </div>


  <div class="col-sm-12 calendar">
    <p style="margin-top:15px; margin-left:60px; font-weight:bold"><img style="width:14px; height:14px" src="<?php ABSPATH ; ?>/wp-content/plugins/custom-dashboard/icon.png"> &nbsp;YOUR LIVE POSTS</p>


    <div class="wrap">
      <div class="row availability">
	<!--
        <?php if ($mode_full) { ?>
        <div class="col-sm-12 field">check availability</div>
        <div class="col-sm-12 value"><?php $roster->display('l<\b\r />M j, Y', false, 'Time<br />Slot'); ?></div>
        <?php } ?>
	-->
		
        <div class="col-sm-12 value" style="text-align: center;">
		<!--<?php echo($user->userName); ?> recently updated their availability on <?php echo($updated); ?>-->
				<div class="col-sm-3">
				  <div class="photo">
					<div class="frame" style="margin:15px">
					  <?php echo(get_avatar($user->id, 150)); ?>
					</div>
				  </div>
				</div>
				
				<div class="col-sm-9">
					<div class="col-sm-12" align=left>
						<u style="font-weight:bold; color:#3095F1;">WHY YOU CHOOSE OUR TEAM?</u>
					</div>
					<div class="col-sm-12" align=left>
						There are many variations of passages of Lorem Ipsum available, ...
					</div>
				</div>		
		</div>
      </div>
    </div>
  </div>

</div>




</div>

<script type="text/javascript">
    
    //<!--  Load the slider  --> 
    jQuery(window).load(function() {
        jQuery('#slider').nivoSlider();
    });
    
</script>

