<?php global $wpdb; ?>
<div class="wrap">  
<?php //include("seatt_header.php"); 
    echo "<h2>" . __( 'List of attendees for the event:', 'seatt_trdom' ) . "</h2>"; 
	
	$pagenum=20;
	
	$s = $_POST['s'];
	if(empty($_GET['filter'])) $subsql = ""; else $subsql = "and a.approve_status=1 ";
	if (isset($_GET['event_id'])) $event_id = $_GET['event_id'];	else $event_id = "-";


	$user_id = get_current_user_id();
	$current_user = wp_get_current_user();
	if($current_user->roles[0] == "group_leader")	//Get Atendee_Data
		$attendees = $wpdb->get_results("SELECT a.*, b.user_nicename, b.user_email, b.display_name 
										 FROM ".$wpdb->prefix."seatt_attendees a, ".$wpdb->prefix."users b,
											   (select p.user_id
											    from ".$wpdb->prefix."usermeta p,
											         (select meta_value from ".$wpdb->prefix."usermeta where meta_key like 'learndash_group_leaders%' and user_id=$user_id)t
											    where p.meta_value = t.meta_value and p.meta_key like 'learndash_group_users%')c	 
										 where a.event_id='$event_id'  and  a.user_id=b.id  and  a.user_id=c.user_id and 
											   b.user_nicename like '%$s%'   $subsql 
										 ORDER BY a.id ");
	else
		$attendees = $wpdb->get_results("SELECT a.*, b.user_nicename, b.user_email, b.display_name 
										 FROM ".$wpdb->prefix."seatt_attendees a, ".$wpdb->prefix."users b 
										 where a.event_id='$event_id' and a.user_id=b.id and 
											   b.user_nicename like '%$s%'	 $subsql									 
										 ORDER BY a.id ");
	
	if(empty($_GET['paged'])) $paged = 1; else $paged = $_GET['paged'];  //current page
	$pages = (count($attendees)%$pagenum==0)?(count($attendees)/$pagenum):intval(count($attendees)/$pagenum)+1;
	if($_GET['flag'] == "next") $paged = $paged + 1;
	if($_GET['flag'] == "prev") $paged = $paged - 1;
	if($_GET['flag'] == "last") $paged = $pages;
	if($_GET['flag'] == "first") $paged = 1;
	
	if($paged>$pages) $paged = $pages;
	$srow = ($paged - 1)*$pagenum;
	$erow = $paged*$pagenum - 1;	
?>	

<div>
	<select style="width:600px; height:35px; font-size:14px" id="event_id" name="event_id" onchange="dataview(this.value);">
		<option value="-">---SELECT EVENT / COURSE---</option>
		<?
			$results = $wpdb->get_results( "SELECT a.*, b.post_title FROM ".$wpdb->prefix."seatt_events a,".$wpdb->prefix."posts b where a.event_course=b.id and a.event_status=1 ORDER BY a.id " );
			foreach ($results as $result) {
					$duaring = date("F j, Y, g:ia", esc_html($result->event_start))." - ".date("g:ia", esc_html($result->event_expire));
					$course = esc_html($result->post_title);
			?>
				<option value='<? echo $result->id;?>'><? echo $result->event_name ." (".$course.") / ".$duaring;?></option>												
		<?}?>
	</select>
	<script>document.getElementById('event_id').value='<?echo $event_id;?>'</script>
</div>

<ul class="subsubsub">
	<li class="all"><a href="admin.php?page=seatt_events_attend&event_id=<?echo $event_id;?>">Attendees <span class="count">(<?echo count($attendees); ?>)</span></a> |</li>
	<li class="publish"><a href="admin.php?page=seatt_events_attend&filter=past&event_id=<?echo $event_id;?>">Pending approval <span class="count" id="pending"></span></a></li>
</ul>

<form method="post" action="admin.php?page=seatt_events_attend&event_id=<?echo $event_id;?>">
<p class="search-box">
	<input type="search" id="post-search-input" name="s" value="<?echo $s;?>">
	<input type="submit" id="search-submit" class="button" value="Search">
</p>
</form>
	
<div class="tablenav top">
	<div class="alignleft actions bulkactions">
		<select name="action" id="bulk-action-selector-top">
			<option value="-1">Bulk approve</option>
			<option value="pending">Pending approval</option>
		</select>
		<input type="submit" id="doaction" class="button action" value="OK">
	</div>
	
	<div class="tablenav-pages <?if($pages <= 1 && $paged <= 1) echo "one-page";?>">
		<span class="displaying-num"><?echo count($attendees);?> elementos</span>
		<span class="pagination-links">
		
		<?if($paged == 1){?>
			<span class="tablenav-pages-navspan" aria-hidden="true">«</span>
			<span class="tablenav-pages-navspan" aria-hidden="true">‹</span>
		<?}else{?>	
			<a class="first-page" href="admin.php?page=seatt_events_attend&flag=first&event_id=<?echo $event_id;?>">
				<span aria-hidden="true">«</span>
			</a>
			<a class="prev-page" href="admin.php?page=seatt_events_attend&flag=prev&paged=<?echo $paged;?>&event_id=<?echo $event_id;?>">
				<span aria-hidden="true">‹</span>
			</a>
		<?}?>
			<span class="paging-input">
				<input class="current-page" id="paged" type="text" value="<?echo $paged?>" size="1" aria-describedby="table-paging" onkeypress="paged_enter(event)"> de 
				<span class="total-pages"><?echo $pages;?></span>
			</span>
		<?if($paged == $pages){?>	
			<span class="tablenav-pages-navspan" aria-hidden="true">›</span>
			<span class="tablenav-pages-navspan" aria-hidden="true">»</span>
		<?}else{?>	
			<a class="next-page" href="admin.php?page=seatt_events_attend&flag=next&paged=<?echo $paged;?>&event_id=<?echo $event_id;?>" >
				<span aria-hidden="true">›</span>
			</a>
			<a class="last-page" href="admin.php?page=seatt_events_attend&flag=last&event_id=<?echo $event_id;?>">
				<span aria-hidden="true">»</span>
			</a>
		<?}?>
			
		</span>
	</div>
	<br class="clear">
</div>

<table class="wp-list-table widefat fixed striped pages">
	<thead>
	<tr>
		<td id="cb" class="manage-column column-cb check-column">
			<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
			<input id="cb-select-all-1" type="checkbox">
		</td>
		<th scope="col" id="title" class="manage-column column-categories column-primary sortable desc">
			<a href="">
				<span>USERNAME</span>
				<span class="sorting-indicator"></span>
			</a>
		</th>
		<th scope="col" id="author" class="manage-column column-categories">NAME</th>
		<th scope="col" id="categories" class="manage-column column-Comments">EMAIL</th>
		<th scope="col" id="tags" class="manage-column column-tags">STATUS</th>
		<th scope="col" id="Comments" class="manage-column column-Comments">ENROLLMENT MANAGEMENT</th>
	</tr>
	</thead>

	<tbody id="the-list">
	
		<?php
		$i = 0;		$pending = 0;
		foreach ($attendees as $attendee) {
		  if($attendee->approve_status == 1)	$pending = $pending + 1;
			
		  if($i>=$srow && $i<=$erow){
		?>
			<tr id="post-<?php echo esc_html($attendee->id); ?>" class="iedit author-other level-0 post-<?php echo esc_html($attendee->id); ?> type-sfwd-courses status-publish hentry category-beta tag-tag1 tag-tag2 user-has-not-earned">
				<th scope="row" class="check-column">			
					<input id="cb-select-<?php echo esc_html($attendee->id); ?>" type="checkbox" name="post[]" value="<?php echo esc_html($attendee->id); ?>">
				</th>
				<td class="categories column-title has-row-actions column-primary page-title" data-colname="Title">
					<strong>
						<?php echo esc_html($attendee->user_nicename); ?>
					</strong>
				</td>
				
				<td class="categories column-categories" data-colname="Author">					
					<?php echo esc_html($attendee->display_name); ?>
				</td>
				
				<td class="comments column-comments" data-colname="Categories">					
					<?php echo esc_html($attendee->user_email); ?>
				</td>
				
				<td class="tags column-tags" data-colname="Tags">
					<span id="S<?echo $attendee->id;?>">
					<?php if($attendee->approve_status == 1) echo "PENDING"; else if($attendee->approve_status == 2)echo "APPROVED"; else echo "UNAPPROVED"; ?>
					</span>
				</td>
				
				<td class="comments column-comments" data-colname="Comments">		
					<div class="post-com-count-wrapper">
						<input type=button class="ev-btn1" value='APROVE' id="A<?echo $attendee->id;?>" onclick="attend_approve('<?echo $attendee->id;?>', '<?echo $attendee->user_email;?>')" <?if($attendee->approve_status == 2)echo "style='visibility:hidden'";?>>
						<input type=button class="ev-btn2" value='X &nbsp;&nbsp;UNAPROVE' id="U<?echo $attendee->id;?>" onclick="attend_unapprove('<?echo $attendee->id;?>', '<?echo $attendee->user_email;?>')">
					</div>
				</td>
					
			</tr>
		<?php
		  }
		$i = $i + 1;
		}
		?>		
	</tbody>

</table>

</div>  
<script>
document.getElementById('pending').innerHTML = "(<?echo $pending;?>)";
function dataview(id){
	window.location.href='admin.php?page=seatt_events_attend&event_id='+id;
}

function attend_approve(id, emailad){
	if(confirm("Will you approve?")){
		jQuery.post(ajaxurl,
					{action: 'event_app', attend_id: id, emailad: emailad}, 
					function(res){
						if(res=="ok"){
							document.getElementById("A"+id).style.visibility="hidden";
							document.getElementById("S"+id).innerHTML = "APPROVED";
						}
					}
		);
	}
}

function attend_unapprove(id, emailad){
	if(confirm("Will you unapprove?")){
		jQuery.post(ajaxurl,
					{action: 'event_unapp', attend_id: id, emailad: emailad}, 
					function(res){
						if(res=="ok"){
							document.getElementById("A"+id).style.visibility="visible";
							document.getElementById("S"+id).innerHTML = "UNAPPROVED";
						}
					}
		);
	}
}

function paged_enter(evt){
	
	if(evt.keyCode == 13){
		window.location.href = "admin.php?page=seatt_events_attend&paged="+document.getElementById('paged').value+"&event_id="+document.getElementById('event_id').value;
	}
}

</script>