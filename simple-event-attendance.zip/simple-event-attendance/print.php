<?
global $wpdb;

$event_id = intval($_GET['event_id']);
$title = $_GET['title'];

$attendees = $wpdb->get_results("SELECT a.*, b.user_nicename, b.user_email, b.display_name 
								 FROM ".$wpdb->prefix."seatt_attendees a, ".$wpdb->prefix."users b 
								 where a.event_id='$event_id' and a.approve_status=2 and a.user_id=b.id ORDER BY a.id ");

$data = "<table border=1 align=center style=\"padding: 0px;border-collapse: collapse;	\">";
$data.= "<tr><td>name</td><td>email</td></tr>";	
							 
	foreach ($attendees as $attendee) {
		$data.= "<tr>";
		$data.= "<td>".$attendee->user_nicename."</td>";
		$data.= "<td>".$attendee->user_email."</td>";
		$data.= "</tr>";
	}
$data.= "</table>";									 
								 
$system = strpos($_SERVER["HTTP_USER_AGENT"],"Windows");
$msie = intval(strpos($browser,"MSIE"));

	if ($system > 0)
		$ext = ".xls";
	else
		$ext = ".ods";
	$type = "application/vnd.ms_excel";

$filename = $title;
$filename=$filename.$ext;
$size= strlen($data)+500;
header("GET ".$filename." HTTP/1.1");
header("Content-Disposition:attachment;filename=".$filename.";"); 
header("Accept-Encoding: ".$type); 
header("Content-Length:".$size);
//header("Content-Transfer-Encoding: binary");
header("Accept-Language: utf-8");
header("Pragma: no-cache"); 
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); 
header("Cache-Control: no-cache, must-revalidate");
header("Expires: 1");

$data ="<html><head><meta http-equiv=Content-Type content=\"text/html; charset=utf-8\"></head><body>".$data;

echo $data."</body></html>";
?>