<?php
/*
Plugin Name: Simple Event Attendance (SEATT)
Version: 1.3.1
Plugin URI: http://www.3cc.org/scripts/wp-seatt-simple-event-attendance/
Author: Dave Channon
Author URI: http://www.3cc.org
Description: Simple attendance list, multiple lists can be added to any post or page and subscribed members can be edited.
*/
global $seatt_db_version;
$seatt_db_version = "1.1.2";
include('seatt_events_include.php');

function seatt_install() {
	global $wpdb;
	global $seatt_db_version;
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
   
	// Install tables----------course field add
	$sql = "CREATE TABLE " . $wpdb->prefix . "seatt_events (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		event_name text NOT NULL,
		event_desc text NOT NULL,
		event_limit mediumint(9) NOT NULL,
		event_reserves mediumint(9) NOT NULL,
		event_start int NOT NULL,
		event_expire int NOT NULL,
		event_status mediumint(1) NOT NULL,
		event_course mediumint(9) NOT NULL,
		UNIQUE KEY id (id)
		) ENGINE = MYISAM CHARACTER SET utf8 COLLATE utf8_general_ci;
		CREATE TABLE " . $wpdb->prefix . "seatt_attendees (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		event_id mediumint(9) NOT NULL,
		user_id int(9) DEFAULT NULL,
		approve_status mediumint(1) NOT NULL,
		user_comment text NOT NULL,
		UNIQUE KEY id (id)
		) ENGINE = MYISAM CHARACTER SET utf8 COLLATE utf8_general_ci;";
	dbDelta($sql);
 
   add_option("seatt_db_version", $seatt_db_version);
   
    $installed_ver = get_option( "seatt_db_version" );

   if ($installed_ver != $seatt_db_version) {

      $sql = "CREATE TABLE " . $wpdb->prefix . "seatt_events (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		event_name text NOT NULL,
		event_desc text NOT NULL,
		event_limit mediumint(9) NOT NULL,
		event_reserves mediumint(9) NOT NULL,
		event_start int NOT NULL,
		event_expire int NOT NULL,
		event_status mediumint(1) NOT NULL,
		event_course mediumint(9) NOT NULL,
		UNIQUE KEY id (id)
		) ENGINE = MYISAM CHARACTER SET utf8 COLLATE utf8_general_ci;
		CREATE TABLE " . $wpdb->prefix . "seatt_attendees (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		event_id mediumint(9) NOT NULL,
		user_id int(9) DEFAULT NULL,
		approve_status mediumint(1) NOT NULL,
		user_comment text NOT NULL,
		UNIQUE KEY id (id)
		) ENGINE = MYISAM CHARACTER SET utf8 COLLATE utf8_general_ci;";
      dbDelta($sql);

      update_option( "seatt_db_version", $seatt_db_version );
  }
}

function seatt_uninstall() {
	global $wpdb;
   
	// Remove tables
	$wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . "seatt_events");
	$wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . "seatt_attendees");
 	
	// Remove option
   delete_option("seatt_db_version");
}


register_activation_hook( __FILE__, 'seatt_install' );
register_uninstall_hook( __FILE__, 'seatt_uninstall' );

function seatt_update_db_check() {
    global $seatt_db_version;
    if (get_site_option('seatt_db_version') != $seatt_db_version) {
        seatt_install();
    }
}

add_action('seatt_loaded', 'seatt_update_db_check');

function seatt_admin() {  
	include('seatt_events_admin.php');
}

function seatt_admin_add() {   
	include('seatt_events_add.php');
}

function seatt_admin_attend() {   
	include('seatt_events_attend.php');
}

function seatt_admin_edit() {   
	include('seatt_events_edit.php');
}

function seatt_admin_actions() {
	add_menu_page("Events", "Events", "level_3", "seatt_events", "seatt_admin" );
	add_submenu_page( "seatt_events", "EVENTS LIST", "EVENTS LIST", "level_3", "seatt_events", "seatt_admin" );
	add_submenu_page( "seatt_events", "ADD NEW EVENT", "ADD NEW EVENT", "level_3", "seatt_events_add", "seatt_admin_add" );
	add_submenu_page( "seatt_events", "ATTENDEES", "ATTENDEES", "level_3", "seatt_events_attend", "seatt_admin_attend" );
	add_submenu_page( "seatt_events", "", "", "level_3", "seatt_events_edit", "seatt_admin_edit" );
	
	wp_enqueue_style('seatt_events', plugins_url('seatt_events.css', __FILE__));
	wp_enqueue_style('jquery-ui', plugins_url('jquery-ui.css', __FILE__));
	wp_enqueue_script('jquery-ui', plugins_url('jquery-ui.js', __FILE__));
}

add_action('admin_menu', 'seatt_admin_actions');

//Group_leader ATTENDEES
add_action('admin_menu', 'my_plugin_menu');
function my_plugin_menu() {
	$current_user = wp_get_current_user();
	if($current_user->roles[0] == "group_leader")
	add_dashboard_page('ATTENDEES', 'ATTENDEES', 'read', 'seatt_events_attend', 'seatt_admin_attend');
}

//Offline_Course Interface
add_action('the_content', 'Offline_Course'); 
function Offline_Course( $post_ID )  
{   
	include('seatt_offlinecourse.php');
    return $post_ID;
}

//Attendee Print
add_action('init', 'attendee_print');
function attendee_print()  
{   
	if(empty($_REQUEST['attendee_print']))return;
	include('print.php');
}

function seatt_func( $atts ) {
	extract( shortcode_atts( array(
		'event_id' => '1',
	), $atts ) );

	return seatt_form("{$event_id}");
}
add_shortcode( 'seatt-form', 'seatt_func' );



//Course approve to Group Leader
add_action( 'wp_ajax_event_req', 'event_req' );
function event_req() {
	global $wpdb; 

	$event_id = intval( $_POST['event_id'] );
	$user_id = get_current_user_id();
	$my_address = get_userdata( $user_id )->user_email;	
	$headers = "From: My Name <".$my_address.">" . "\r\n";
	
    //Get Group Leader 
	$results = $wpdb->get_results( "select user_id from ".$wpdb->prefix."usermeta where meta_key like 'learndash_group_leaders%' and meta_value in (SELECT meta_value FROM ".$wpdb->prefix."usermeta WHERE user_id = '$user_id' and meta_key like 'learndash_group_users%') " );
	
	if(count($results)>0){
		$wpdb->insert($wpdb->prefix.'seatt_attendees', array( 'event_id' => $event_id, 'user_id' => $user_id, 'approve_status' => 1 ), array('%d', '%d', '%d') );
		
		foreach ($results as $result) {//Send mail to Group Leader
			$Group_leader_id = $result->user_id;
			$email_address = get_userdata( $Group_leader_id )->user_email;
			wp_mail( $email_address, "I Approve", 'I want to enroll the course', $headers );
		}
		echo "ok";
	}else{
		echo "groupno";
	}
	
	wp_die(); 
}

//Group Leader Approve user enroll
add_action( 'wp_ajax_event_app', 'event_app' );
function event_app() {
	global $wpdb; 

	$attend_id = intval( $_POST['attend_id'] );
	$emailad =  $_POST['emailad'] ;
	
	$user_id = get_current_user_id();
	$my_address = get_userdata( $user_id )->user_email;
	$headers = "From: My Name <".$my_address.">" . "\r\n";
	
    $wpdb->update($wpdb->prefix.'seatt_attendees', array( 'approve_status' => 2 ), array( 'id' => $attend_id ), array('%d'));
	wp_mail( $emailad, "You Are Approved", 'You can enroll the course', $headers );		
	
	echo "ok";
	wp_die(); 
}

//Group Leader Approve user enroll
add_action( 'wp_ajax_event_unapp', 'event_unapp' );
function event_unapp() {
	global $wpdb; 

	$attend_id = intval( $_POST['attend_id'] );
	$emailad =  $_POST['emailad'] ;
	
	$user_id = get_current_user_id();
	$my_address = get_userdata( $user_id )->user_email;
	$headers = "From: My Name <".$my_address.">" . "\r\n";
	
    $wpdb->update($wpdb->prefix.'seatt_attendees', array( 'approve_status' => 3 ), array( 'id' => $attend_id ), array('%d'));
	wp_mail( $emailad, "You Are Unapproved", 'You can not enroll the course', $headers );
	
	echo "ok";
	wp_die(); 
}

?>