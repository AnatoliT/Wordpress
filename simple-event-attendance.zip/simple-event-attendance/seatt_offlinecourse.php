<?
	wp_enqueue_style('seatt_events', plugins_url('seatt_events.css', __FILE__));
	wp_enqueue_style('jquery-ui', plugins_url('jquery-ui.css', __FILE__));
	wp_enqueue_script('jquery-ui', plugins_url('jquery-ui.js', __FILE__));
	
	$id = get_the_ID();
	global $wpdb;
	$results = $wpdb->get_results( "SELECT a.post_title FROM ".$wpdb->prefix."posts a, ".$wpdb->prefix."seatt_events b WHERE a.id = b.event_course and a.id = '$id' " );
	
if (count($results) > 0){//Offline Course exist
	
	$course = $results[0]->post_title;
	$user_id = get_current_user_id();
	$current_user_name = wp_get_current_user()->user_nicename; 
	
	$events = $wpdb->get_results( " SELECT a.*, b.approve_status from (SELECT * FROM ".$wpdb->prefix."seatt_events  WHERE event_course = '$id' and event_start-unix_timestamp()>=0 )a left join (SELECT * FROM ".$wpdb->prefix."seatt_attendees  WHERE user_id = '$user_id')b on (a.id=b.event_id) order by a.id " );
	
	if(count($events)>0){
?>
<div style="font-family: sans-serif; ">
	<span style="color:black">Select only one date: When do you want to take this course?</span>
	<form>
	
	<?
	foreach ($events as $event) {
		$event_id = esc_html($event->id);
		$event_name = esc_html($event->event_name);
		$event_desc = esc_html($event->event_desc);
		$event_limit = $event->event_limit;
		$event_reserves = $event->event_reserves;
		$event_status = $event->event_status;
		$approve_status = $event->approve_status;
		
		$event_start = date("Y-m-d H:i", esc_html($event->event_start));
		$event_start_day = date("l", esc_html($event->event_start));
		$event_start_month = date("F", esc_html($event->event_start));
		$event_start_date = date("j", esc_html($event->event_start));
		$event_start_time = date("g:ia", esc_html($event->event_start));
		
		$event_expire = date("Y-m-d H:i", esc_html($event->event_expire));
		$event_expire_time = date("g:ia", esc_html($event->event_expire));
		
		//$seat_dif = $event_limit-$event_reserves;
		$attendees = $wpdb->get_var($wpdb->prepare("SELECT COUNT(id) FROM ".$wpdb->prefix."seatt_attendees WHERE approve_status=2 and event_id = %d", $event_id));
		$seat_dif = $event_limit-$attendees;
	?>
	
		<div class="pi-right-panel pi-box">
		
			<table width=97% height=120px border=0 style="border-color:white; font-size:10px; margin-bottom:10px;">
				<tr height=120px valign=middle>
					<td width="210px" style="border:0px; padding:0px; text-align: center;" id="<?echo $event_id;?>">
					
						<div class="col-sm-4 timing">
							<div class="time-cont">
								<div class="eve-start">
									<time datetime="<?echo $event_start;?>" class="icon">
									<em><?echo $event_start_day;?></em>
									<strong><?echo $event_start_month;?></strong>
									<span><?echo $event_start_date;?></span>
									</time>
									<p style="position: relative;"> 
									<img src="<?php echo esc_url( home_url( '/' ) ); ?>wp-content/plugins/simple-event-attendance/popup-time-icon.png" style="  float: left;margin-right: 3px;margin-top: 2px;">
									<?echo $event_start_time;?> - <?echo $event_expire_time;?></p>
								</div>
							</div>
						</div>
					</td>
					
					<td style="border: 0px; padding:0px">
						<p style="margin-bottom:0px;margin-top:20px; font-size:16px"><? echo $event_name; ?>(Presential course <? echo $course;?>)</p>
						<p style="margin-bottom:20px;"><span style="font-size:13px" id="L<?echo $event_id;?>">Location: <? echo $event_desc; ?></span></p>
						
						<p style="font-size:13px;">
							<span  style="padding-top:5px">Open seats:</span>
							<input type=button class="<? if($seat_dif==0) echo "ev-btn5-0"; else echo "ev-btn5"; ?>" value="<?echo $seat_dif;?>" disabled id="S<?echo $event_id;?>">
							<span style="padding-top:5px">of</span> 
							<b><? echo $event_limit; ?></b>
							
						</p>
					
					</td>
					<td  style="border: 0px; padding:0px; text-align: center;" width=250px>
						<?if($approve_status == 1) echo "<input type=button class='ev-btn4-full' value='Application sent' disabled>
															<p>Thank you, please wait for a confirmation email</p>";
						  else if($approve_status == 2)	echo "<input type=button class='ev-btn4-app' value='Approved' disabled>
																<p>We'll see you there</p>";
						  else if($approve_status == 3)  echo "<input type=button class='ev-btn4-noapp' value='Not approved' disabled>
																<p>Please, select another date or contact your manager</p>";
						  else {
							  if($seat_dif==0) echo "<input type=button class='ev-btn4-full' value='Course is full' disabled>";
							  else echo "<input type=button class='ev-btn4' value='Take this course' onclick = 'app_win(".$event_id.",this)' id=B".$event_id.">";
						  }
						?>
					</td>
				</tr>
			</table>
		</div>
	<?}	}?>
	
	</form>	

<br>	
<div>
<?}?>
<div id="dialog-confirm"></div>
<script>
	var user_name= "<?echo $current_user_name;?>";
        function app_win(id){
			jQuery("#dialog-confirm").html("<strong>[Blog Name]</strong><br><span>A new application is waiting for your approbation</span><br><strong>[Event Name]</strong><br>"+document.getElementById('L'+id).innerHTML+document.getElementById(id).innerHTML+"<div style='margin-left:200px'><p>"+user_name+"</p><span>Open seats:"+document.getElementById('S'+id).value+"</span></div>");

			jQuery("#dialog-confirm").dialog({
				dragabble:true,
				resizable: false,
				modal: true,
				title: "Will You Approve?",
				height: 380,
				width: 550,
				buttons: {
					"APPROVE": function () {
							jQuery(this).dialog('close');
							jQuery.post(ajaxurl,
										{action: 'event_req', event_id: id}, 
										function(res){
											if(res=="ok"){
												document.getElementById("B"+id).value="Application sent";
												jQuery("#B"+id).removeClass("ev-btn4").addClass("ev-btn4-full");
												document.getElementById("B"+id).disabled = true;
											}else{
												alert("You have not Group");
											}
										}
							);
					},
					"UNAPPROVE": function () {
						jQuery(this).dialog('close');
					}
				}
			});
			
		};
		
		
			
           
</script>