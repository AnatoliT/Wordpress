<div class="wrap">  

        <?php    echo "<h2>" . __( 'Add New Event', 'seatt_trdom' ) . "</h2>";
		  // Process form if sent
          if(isset($_POST['seatt_name'])) {
			$_POST = stripslashes_deep($_POST);  
			$event_name = sanitize_text_field($_POST['seatt_name']);
			$event_desc = sanitize_text_field($_POST['seatt_desc']);
			$event_limit = intval($_POST['seatt_limit']);
			$event_start = strtotime($_POST['seatt_start']);
			$event_expire = strtotime($_POST['seatt_expire']);
			$event_course = sanitize_text_field($_POST['course']);
			
			// Ensure required fields contain values, insert if true
			if ((strlen(trim($event_name)) > 0) &&
				($event_start) &&
				($event_expire)) {
							
				global $wpdb;
				$wpdb->insert($wpdb->prefix.'seatt_events', array( 'event_name' => $event_name, 'event_desc' => $event_desc, 'event_limit' => $event_limit, 'event_start' => $event_start, 'event_expire' => $event_expire, 'event_status' => 1, 'event_reserves' => 0, 'event_course' => $event_course ), array('%s', '%s', '%d', '%s', '%s', '%d', '%d', '%s') );
				?>
				<div class="updated">
                	<p><strong>Event <?php echo esc_html($event_name); ?> added.</strong></p>
                </div>
				<?php
				
			  } else {
				// If required fields missing
			  	?>
                <div class="error">
                	<p><strong>Please ensure that all required fields contain values, and that dates are in a valid format.</strong></p>
                </div>
                <?php
			}
		  }
		?>
		  <p></p>
		<form name="seatt_add_form" method="post" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>">
		     
		  <table width=80% height="500px" border=0 style="margin-left:70px; font-weight:bold">
			<tr height=15% align=left valign=middle>
				<td width="110px">	Event title	</td>
				<td>
					<input name="seatt_name" type="text" id="seatt_name" size="50" maxlength="150" style="height:35px">
				</td>
			</tr>
			<tr height=15%>
				<td>	Location	</td>
				<td>
					<input name="seatt_desc" type="text" id="seatt_desc" size="50" maxlength="150" style="height:35px">
				</td>
			</tr>
			<tr height=15%>
				<td>	Available seats		</td>
				<td>
					<input name="seatt_limit" type="number" id="seatt_limit" value="0" style="height:35px; width:100px" min="0" autocomplete="off" role="spinbutton">
				</td>
			</tr>
			<tr height=15%>
				<td>	Stars	</td>
				<td>
					<input id="start_d" type="date" style="height:35px" value="<?php echo date("Y-m-d", current_time('timestamp')); ?>" onchange="document.getElementById('expire_d').value=this.value;" />
					<input id="start_t" type="time" style="height:35px" value="<?php echo date("H:i", current_time('timestamp')); ?>" />
					<input name="seatt_start" type="hidden" id="seatt_start"  />
				</td>
			</tr>
			<tr height=15%>
				<td>	Ends	</td>
				<td>
					<input id="expire_d" type="date" style="height:35px" value="<?php echo date("Y-m-d", current_time('timestamp')); ?>" />
					<input id="expire_t" type="time" style="height:35px" value="<?php echo date("H:i", current_time('timestamp')); ?>"/>
					<input name="seatt_expire" type="hidden" id="seatt_expire" />
				</td>
			</tr>
			<tr height=15%>
				<td>	Couse	</td>
				<td>
					<select id="course" name="course" style="width:280px; height:35px">
						<?
						global $wpdb;
						$results = $wpdb->get_results( "SELECT a.id, a.post_title FROM ".$wpdb->prefix."posts a, ".$wpdb->prefix."postmeta b WHERE a.id = b.post_id and b.meta_key like '_sfwd-courses' and b.meta_value like '%sfwd-courses_course_price_type%closed%sfwd-courses_custom_button_url%' order by a.id" );
						foreach ($results as $course) {?>
							<option value='<? echo $course->id;?>'><? echo $course->post_title;?></option>												
						<?}?>
					</select>
				</td>
			</tr>
			<tr height=15%>
				<td></td>
				<td>
					<input type="submit" name="Submit" class="ev-btn3" value="<?php _e('ADD THIS EVENT', 'seatt_trdom' ) ?>" onclick="dateset();" />
				</td>
			</tr>
		  </table>
		  
</div>
<script>
function dateset(){
	document.getElementById('seatt_start').value=document.getElementById('start_d').value+document.getElementById('start_t').value;
	document.getElementById('seatt_expire').value=document.getElementById('expire_d').value+document.getElementById('expire_t').value;
}
</script>